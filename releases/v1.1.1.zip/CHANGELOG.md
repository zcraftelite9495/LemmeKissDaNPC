# Changelog: 1.1.1
* 🔄 Updated the code to be compatible with EasySettings 1.1.3

# Changelog: 1.1.0
* ➕ Added an easter egg to the game to make things more interesting
* 🔄 Re-laid out the code to make it more readable
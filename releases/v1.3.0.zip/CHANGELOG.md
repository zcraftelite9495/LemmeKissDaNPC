# Changelog: 1.2.0
* ➕ MAJOR BREAKTHROUGH: Gained access to the `_jumpOffCollider` object and disabled it, keeping the entity from turning on collision.
* 🔄 Updated the code to be compatible with ATLYSS Beta 1.5.8a.

# Changelog: 1.1.1
* 🔄 Updated the code to be compatible with EasySettings 1.1.3.

# Changelog: 1.1.0
* ➕ Added an easter egg to the game to make things more interesting.
* 🔄 Re-laid out the code to make it more readable.

# Changelog: 1.2.0
* ➕ Added feature to remove the jump-off collider, fixing the bug where you could sometimes still bounce off of NPCs

# Changelog: 1.3.0
* ➕ Compatibility Update: Updated compatibility for ATLYSS v1.6.2b